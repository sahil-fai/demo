import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-single-ledger-master-component',
  templateUrl: './single-ledger-master-component.component.html',
  styleUrls: ['./single-ledger-master-component.component.less']
})
export class SingleLedgerMasterComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
