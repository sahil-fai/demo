import { StylePaginatorDirective } from './style-paginator.directive';

describe('StylePaginatorDirective', () => {
  it('should create an instance', () => {
    const directive = new StylePaginatorDirective();
    expect(directive).toBeTruthy();
  });
});
