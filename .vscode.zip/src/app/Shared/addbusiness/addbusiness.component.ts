import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbusiness',
  templateUrl: './addbusiness.component.html',
  styleUrls: ['./addbusiness.component.less']
})
export class AddbusinessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
